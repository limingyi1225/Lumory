const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '.env') });
const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
console.log('🔑 Loaded OPENROUTER_API_KEY:', OPENROUTER_API_KEY);
if (!OPENROUTER_API_KEY) {
  console.error('❌ Missing OPENROUTER_API_KEY! 请在 server/.env 中设置该值');
  process.exit(1);
}
const OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1';

app.post('/api/openrouter/chat/completions', async (req, res) => {
  try {
    const resp = await axios.post(
      `${OPENROUTER_BASE_URL}/chat/completions`,
      req.body,
      {
        headers: {
          Authorization: `Bearer ${OPENROUTER_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    res.json(resp.data);
  } catch (err) {
    console.error('OpenRouter Error:', err.response?.data || err.message);
    res.status(err.response?.status || 500)
       .json({ error: err.response?.data || err.message });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`🔌 后端服务已启动，监听端口 ${port}`);
});
